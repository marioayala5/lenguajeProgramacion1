package unidad3;

public class PruebaKilometraje {

    public static void main(String[] args) {
        Kilometraje km = new Kilometraje();

        km.RegistroKilometraje();
    }
}
