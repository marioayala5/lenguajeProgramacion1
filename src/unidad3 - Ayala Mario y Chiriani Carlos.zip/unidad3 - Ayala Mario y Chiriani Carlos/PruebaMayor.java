package unidad3;

public class PruebaMayor {

    public static void main(String[] args) {
        Mayor mayor = new Mayor();
        
        mayor.valorMayor();
    }
    
}
