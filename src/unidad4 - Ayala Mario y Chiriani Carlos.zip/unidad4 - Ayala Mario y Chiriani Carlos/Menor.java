package unidad4;

import java.util.Scanner;

public class Menor {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);        
        
        int enteros;
        int contador = 1;
        int menor;
        int nro;
        System.out.print("Escriba la cantidad de valores enteros a introducir: ");
        enteros = entrada.nextInt();
        
        System.out.printf("\nIntroduzca el numero de la iteracion %d:  ", contador);
        nro = entrada.nextInt();
        menor = nro;
        
        while (enteros > contador) {
            System.out.printf("Introduzca el numero de la iteracion %d:  ", ++contador);
            nro = entrada.nextInt();
            if (nro < menor) {
                menor = nro;
            }
        }
        System.out.printf("\nEl numero inferior entre los %d valores introducidos es: %d\n", contador, menor);
    } 
}
