package unidad4;

import java.text.DecimalFormat;

public class ProductoImpar {
    public static void main(String[] args) {
        DecimalFormat separador = new DecimalFormat("###,###.##");
        int impar = 1;
        for (int contador = 1; contador <= 15; contador++) {
            if (contador % 2 != 0) {
                impar *= contador;
            }
        }
        System.out.printf("\nEl producto de los numeros enteros impares del 1 al 15 es: ", separador.format(impar));
    }
}
